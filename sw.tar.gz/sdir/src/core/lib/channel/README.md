# Channel

Provides channel/call stack implementation, and implementation of common filters
for that implementation.
